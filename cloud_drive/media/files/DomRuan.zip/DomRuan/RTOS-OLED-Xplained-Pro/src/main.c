#include <asf.h>
#include "conf_board.h"

#include "gfx_mono_ug_2832hsweg04.h"
#include "gfx_mono_text.h"
#include "sysfont.h"

#define LED_PIO      PIOC
#define LED_PIO_ID   ID_PIOC
#define LED_IDX      8
#define LED_IDX_MASK (1 << LED_IDX)

#define PIO_CLK           PIOD
#define PIO_CLK_ID        ID_PIOD
#define PIO_CLK_IDX       30
#define PIO_CLK_IDX_MASK  (1u << PIO_CLK_IDX)

#define PIO_DT           PIOA
#define PIO_DT_ID        ID_PIOA
#define PIO_DT_IDX       6
#define PIO_DT_IDX_MASK  (1u << PIO_DT_IDX)

#define PIO_SW           PIOC
#define PIO_SW_ID        ID_PIOC
#define PIO_SW_IDX       19
#define PIO_SW_IDX_MASK  (1u << PIO_SW_IDX)

volatile char desceu_clk;
volatile float desceu_sw;
volatile float tempo;

QueueHandle_t xQueueSelecao;
QueueHandle_t xQueueTroca;
QueueHandle_t xQueueReseta;

/** RTOS  */
#define TASK_SELECAO_STACK_SIZE                (1024*6/sizeof(portSTACK_TYPE))
#define TASK_SELECAO_STACK_PRIORITY            (tskIDLE_PRIORITY)
#define TASK_RESETA_STACK_SIZE                (1024*6/sizeof(portSTACK_TYPE))
#define TASK_RESETA_STACK_PRIORITY            (tskIDLE_PRIORITY)

extern void vApplicationStackOverflowHook(xTaskHandle *pxTask,  signed char *pcTaskName);
extern void vApplicationIdleHook(void);
extern void vApplicationTickHook(void);
extern void vApplicationMallocFailedHook(void);
extern void xPortSysTickHandler(void);

/** prototypes */
void clk_callback(void);
void dt_callback(void);
void sw_callback(void);
void pisca_led(int n, int t);
static void BUT_init(void);

/************************************************************************/
/* RTOS application funcs                                               */
/************************************************************************/

extern void vApplicationStackOverflowHook(xTaskHandle *pxTask, signed char *pcTaskName) {
	printf("stack overflow %x %s\r\n", pxTask, (portCHAR *)pcTaskName);
	for (;;) {	}
}

extern void vApplicationIdleHook(void) { }

extern void vApplicationTickHook(void) { }

extern void vApplicationMallocFailedHook(void) {
	configASSERT( ( volatile void * ) NULL );
}


/************************************************************************/
/* handlers / callbacks                                                 */
/************************************************************************/

void clk_callback(void) {
	if (!pio_get(PIO_CLK, PIO_INPUT, PIO_CLK_IDX_MASK)){
		desceu_clk = 1;
		BaseType_t xHigherPriorityTaskWoken = pdTRUE;
		xQueueSendFromISR(xQueueSelecao, &desceu_clk, &xHigherPriorityTaskWoken);
	} else{
		desceu_clk = 0;
	}
}

void sw_callback(void) {
	BaseType_t xHigherPriorityTaskWoken = pdTRUE;
	if (!pio_get(PIO_SW, PIO_INPUT, PIO_SW_IDX_MASK)) {
		rtt_init(RTT, 1);
		desceu_sw = 1;
		xQueueSendFromISR(xQueueTroca, &desceu_sw, &xHigherPriorityTaskWoken);
	}
	else{
		float t;
		tempo = rtt_read_timer_value(RTT);
		t = tempo/32768.0;
		if (t > 5){
			printf("entrou");
			//xQueueSendFromISR(xQueueReseta, &t, &xHigherPriorityTaskWoken);
		}
		
	}
	
}

/************************************************************************/
/* TASKS                                                                */
/************************************************************************/

static void task_selecao(void *pvParameters) {
	gfx_mono_ssd1306_init();
	gfx_mono_draw_string("0", 10,22, &sysfont);
	gfx_mono_draw_string("0", 20,22, &sysfont);
	gfx_mono_draw_string("0", 30,22, &sysfont);
	gfx_mono_draw_string("0", 40,22, &sysfont);
	char desceu_c;
	float desceu_s;
	int n = 0;
	int k = 10;
	for (;;)  {
		if (xQueueReceive(xQueueSelecao, &(desceu_c), 100)){
			if (pio_get(PIO_DT, PIO_INPUT, PIO_DT_IDX_MASK)){
				n++;
			}
			else {
				n--;
			}
			if (n < 0){
				n = 15;
			}
			if (n > 15){
				n = 0;
			}
			printf("%d", n);
		}
		if (xQueueReceive(xQueueTroca, &(desceu_s), 100)){
			printf("%d", k);
			k+=10;
			n = 0;
			if (k > 40){
				k = 10;
			}
		}
		char str[128];
		sprintf(str, "%x", n);
		gfx_mono_draw_string(" ", k,22, &sysfont);
		vTaskDelay(25);
		gfx_mono_draw_string(str, k,22, &sysfont);
		vTaskDelay(25);
	}
}

static void task_reseta(void *pvParameters){
	float t;
	for (;;) {
		if (xQueueReceive(xQueueReseta, &(t), 100)) {
			if (t > 5.0){
				pisca_led(20, 50);
				gfx_mono_ssd1306_init();
				gfx_mono_draw_string("0", 10,22, &sysfont);
				gfx_mono_draw_string("0", 20,22, &sysfont);
				gfx_mono_draw_string("0", 30,22, &sysfont);
				gfx_mono_draw_string("0", 40,22, &sysfont);
			}
		}
	}
	
}

/************************************************************************/
/* funcoes                                                              */
/************************************************************************/

void pisca_led(int n, int t){
	for (int i=0;i<n;i++){
		pio_clear(LED_PIO, LED_IDX_MASK);
		delay_ms(t);
		pio_set(LED_PIO, LED_IDX_MASK);
		delay_ms(t);
	}
}

static void configure_console(void) {
	const usart_serial_options_t uart_serial_options = {
		.baudrate = CONF_UART_BAUDRATE,
		.charlength = CONF_UART_CHAR_LENGTH,
		.paritytype = CONF_UART_PARITY,
		.stopbits = CONF_UART_STOP_BITS,
	};

	/* Configure console UART. */
	stdio_serial_init(CONF_UART, &uart_serial_options);

	/* Specify that stdout should not be buffered. */
	setbuf(stdout, NULL);
}

static void BUT_init(void) {
	
	pmc_enable_periph_clk(LED_PIO_ID);
	pio_configure(LED_PIO, PIO_OUTPUT_0, LED_IDX_MASK, PIO_DEFAULT);
	
	/* conf echo como entrada */
	pmc_enable_periph_clk(PIO_CLK_ID);
	pio_configure(PIO_CLK, PIO_INPUT, PIO_CLK_IDX_MASK, PIO_PULLUP | PIO_DEBOUNCE);
	pio_set_debounce_filter(PIO_CLK, PIO_CLK_IDX_MASK, 60);
	pio_handler_set(PIO_CLK, PIO_CLK_ID, PIO_CLK_IDX_MASK, PIO_IT_EDGE , clk_callback);
	pio_enable_interrupt(PIO_CLK, PIO_CLK_IDX_MASK);
	
	pmc_enable_periph_clk(PIO_DT_ID);
	pio_configure(PIO_DT, PIO_INPUT, PIO_DT_IDX_MASK, PIO_PULLUP | PIO_DEBOUNCE);
	pio_set_debounce_filter(PIO_DT, PIO_DT_IDX_MASK, 60);
	
	pmc_enable_periph_clk(PIO_SW_ID);
	pio_configure(PIO_SW, PIO_INPUT, PIO_SW_IDX_MASK, PIO_PULLUP | PIO_DEBOUNCE);
	pio_set_debounce_filter(PIO_SW, PIO_SW_IDX_MASK, 60);
	pio_handler_set(PIO_SW, PIO_SW_ID, PIO_SW_IDX_MASK, PIO_IT_EDGE , sw_callback);
	pio_enable_interrupt(PIO_SW, PIO_SW_IDX_MASK);
	
	/* configura prioridae */
	NVIC_EnableIRQ(PIO_SW_ID);
	NVIC_SetPriority(PIO_SW_ID, 4);
	
	NVIC_EnableIRQ(PIO_CLK_ID);
	NVIC_SetPriority(PIO_CLK_ID, 5);
}

/************************************************************************/
/* main                                                                 */
/************************************************************************/


int main(void) {
	/* Initialize the SAM system */
	sysclk_init();
	board_init();
	BUT_init();

	/* Initialize the console uart */
	configure_console();
	
	xQueueSelecao = xQueueCreate(100, sizeof(char));
	if (xQueueSelecao == NULL)
	printf("falha em criar a queue xQueueEcho \n");
	
	xQueueTroca = xQueueCreate(100, sizeof(float));
	if (xQueueTroca == NULL)
	printf("falha em criar a queue xQueueEcho \n");
	
	xQueueReseta = xQueueCreate(100, sizeof(float));
	if (xQueueReseta == NULL)
	printf("falha em criar a queue xQueueEcho \n");

	if (xTaskCreate(task_selecao, "selecao", TASK_SELECAO_STACK_SIZE, NULL, TASK_SELECAO_STACK_PRIORITY, NULL) != pdPASS) {
	  printf("Failed to create selecao task\r\n");
	}
	if (xTaskCreate(task_reseta, "reseta", TASK_RESETA_STACK_SIZE, NULL, TASK_RESETA_STACK_PRIORITY, NULL) != pdPASS) {
		printf("Failed to create reseta task\r\n");
	}

	/* Start the scheduler. */
	vTaskStartScheduler();

  /* RTOS n�o deve chegar aqui !! */
	while(1){}

	/* Will only get here if there was insufficient memory to create the idle task. */
	return 0;
}
